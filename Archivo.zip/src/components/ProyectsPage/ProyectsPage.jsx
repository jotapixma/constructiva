import React from 'react';

const ProyectsPage = () => {
  return (  
    <h2>Esta es la pagina de proyectos</h2>
  );
}
 
export default ProyectsPage;