exports.id = 174;
exports.ids = [174];
exports.modules = {

/***/ 89:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "Footer_footer__Q5T55",
	"gridColumns": "Footer_gridColumns__PAEwc",
	"footerLogo": "Footer_footerLogo__ZEuzE",
	"itemColumn": "Footer_itemColumn__GoWNl",
	"unorderList": "Footer_unorderList__4OC6X"
};


/***/ }),

/***/ 7426:
/***/ ((module) => {

// Exports
module.exports = {
	"footerWinch": "FooterWinch_footerWinch__urep1",
	"footerWinch__info": "FooterWinch_footerWinch__info__CO_cO",
	"title": "FooterWinch_title__ocI5t",
	"footerWinch__rights": "FooterWinch_footerWinch__rights__VLyIo",
	"textBrand": "FooterWinch_textBrand__s4bHN"
};


/***/ }),

/***/ 5731:
/***/ ((module) => {

// Exports
module.exports = {
	"itemLink": "RrssItem_itemLink__ATaSR"
};


/***/ }),

/***/ 6991:
/***/ ((module) => {

// Exports
module.exports = {
	"bodyPage": "Layout_bodyPage__0A3Gp"
};


/***/ }),

/***/ 5704:
/***/ ((module) => {

// Exports
module.exports = {
	"themeBar": "NavBar_themeBar__2FiGu",
	"logoBox": "NavBar_logoBox__OnlzL",
	"toolBar": "NavBar_toolBar__lXFqE",
	"logoContainer": "NavBar_logoContainer__OQn8H"
};


/***/ }),

/***/ 2174:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "@mui/material/Container"
var Container_ = __webpack_require__(4475);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container_);
// EXTERNAL MODULE: ./node_modules/next/legacy/image.js
var legacy_image = __webpack_require__(9755);
var image_default = /*#__PURE__*/__webpack_require__.n(legacy_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./src/components/Footer/FooterWinch/FooterWinch.module.scss
var FooterWinch_module = __webpack_require__(7426);
var FooterWinch_module_default = /*#__PURE__*/__webpack_require__.n(FooterWinch_module);
;// CONCATENATED MODULE: ./src/components/Footer/FooterWinch/FooterWinch.js





const FooterWinch = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (FooterWinch_module_default()).footerWinch,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (FooterWinch_module_default()).footerWinch__info
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (FooterWinch_module_default()).footerWinch__rights,
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: (FooterWinch_module_default()).textBrand,
                    children: "Constructora LV 2023 \xa9 Todos los derechos reservados"
                })
            })
        ]
    });
};
/* harmony default export */ const FooterWinch_FooterWinch = (FooterWinch);

// EXTERNAL MODULE: external "@mui/icons-material/Facebook"
var Facebook_ = __webpack_require__(7666);
var Facebook_default = /*#__PURE__*/__webpack_require__.n(Facebook_);
// EXTERNAL MODULE: external "@mui/icons-material/WhatsApp"
var WhatsApp_ = __webpack_require__(2232);
var WhatsApp_default = /*#__PURE__*/__webpack_require__.n(WhatsApp_);
// EXTERNAL MODULE: external "@mui/icons-material/Instagram"
var Instagram_ = __webpack_require__(3281);
var Instagram_default = /*#__PURE__*/__webpack_require__.n(Instagram_);
// EXTERNAL MODULE: external "@mui/icons-material/LinkedIn"
var LinkedIn_ = __webpack_require__(5939);
var LinkedIn_default = /*#__PURE__*/__webpack_require__.n(LinkedIn_);
// EXTERNAL MODULE: ./src/components/Footer/RrssItem/RrssItem.module.scss
var RrssItem_module = __webpack_require__(5731);
var RrssItem_module_default = /*#__PURE__*/__webpack_require__.n(RrssItem_module);
;// CONCATENATED MODULE: ./src/components/Footer/RrssItem/RrssItem.jsx








const RrssItem = ({ item  })=>{
    const iconComponent = (item)=>{
        switch(item.title){
            case "facebook":
                return /*#__PURE__*/ jsx_runtime_.jsx((Facebook_default()), {});
            case "whatsapp":
                return /*#__PURE__*/ jsx_runtime_.jsx((WhatsApp_default()), {});
            case "instagram":
                return /*#__PURE__*/ jsx_runtime_.jsx((Instagram_default()), {});
            case "linkedin":
                return /*#__PURE__*/ jsx_runtime_.jsx((LinkedIn_default()), {});
            default:
                return null;
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx((external_react_default()).Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
            href: item.link,
            className: (RrssItem_module_default()).itemLink,
            children: iconComponent(item)
        })
    });
};
/* harmony default export */ const RrssItem_RrssItem = (RrssItem);

// EXTERNAL MODULE: external "@mui/material/Box"
var Box_ = __webpack_require__(19);
var Box_default = /*#__PURE__*/__webpack_require__.n(Box_);
// EXTERNAL MODULE: ./src/components/Footer/Footer.module.scss
var Footer_module = __webpack_require__(89);
var Footer_module_default = /*#__PURE__*/__webpack_require__.n(Footer_module);
;// CONCATENATED MODULE: ./src/components/Footer/Footer.jsx









const Footer = ()=>{
    let items = [
        // {
        //   "id": '1',
        //   "title": 'facebook',
        //   "link": '/',
        // },
        // {
        //   "id": '2',
        //   "title": 'whatsapp',
        //   "link": '/',
        // },
        {
            "id": "3",
            "title": "instagram",
            "link": "https://www.instagram.com/constructora.lv/"
        },
        {
            "id": "4",
            "title": "linkedin",
            "link": "https://www.linkedin.com/in/constructora-lv-spa-002885270"
        }
    ];
    return /*#__PURE__*/ jsx_runtime_.jsx("footer", {
        className: (Footer_module_default()).footer,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Container_default()), {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (Footer_module_default()).gridColumns,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (Footer_module_default()).itemColumn,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: (Footer_module_default()).unorderList,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "Contacto"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "+56 9 6104 5977"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "contacto@lvconstructora.cl"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "Ahumada 254, Oficina 806."
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (Footer_module_default()).itemColumn,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: (Footer_module_default()).unorderList,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "Siguenos"
                                    }),
                                    items && /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                        sx: {
                                            display: "flex",
                                            gap: "1rem",
                                            marginTop: "0.8rem"
                                        },
                                        children: items.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx(RrssItem_RrssItem, {
                                                item: item
                                            }, index))
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (Footer_module_default()).itemColumn,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                                    className: (Footer_module_default()).footerLogo,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: "/logo-constructora-lv-white.png",
                                        width: 1480,
                                        height: 877,
                                        alt: "logo"
                                    })
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(FooterWinch_FooterWinch, {})
            ]
        })
    });
};
/* harmony default export */ const Footer_Footer = (Footer);

// EXTERNAL MODULE: external "@mui/material/useMediaQuery"
var useMediaQuery_ = __webpack_require__(9868);
var useMediaQuery_default = /*#__PURE__*/__webpack_require__.n(useMediaQuery_);
// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(580);
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_);
// EXTERNAL MODULE: external "@mui/material/AppBar"
var AppBar_ = __webpack_require__(3882);
var AppBar_default = /*#__PURE__*/__webpack_require__.n(AppBar_);
// EXTERNAL MODULE: external "@mui/material/CssBaseline"
var CssBaseline_ = __webpack_require__(4960);
var CssBaseline_default = /*#__PURE__*/__webpack_require__.n(CssBaseline_);
// EXTERNAL MODULE: external "@mui/material/Divider"
var Divider_ = __webpack_require__(3646);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider_);
// EXTERNAL MODULE: external "@mui/material/Drawer"
var Drawer_ = __webpack_require__(7898);
var Drawer_default = /*#__PURE__*/__webpack_require__.n(Drawer_);
// EXTERNAL MODULE: external "@mui/material/IconButton"
var IconButton_ = __webpack_require__(7934);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton_);
// EXTERNAL MODULE: external "@mui/material/List"
var List_ = __webpack_require__(4192);
var List_default = /*#__PURE__*/__webpack_require__.n(List_);
// EXTERNAL MODULE: external "@mui/material/ListItem"
var ListItem_ = __webpack_require__(834);
var ListItem_default = /*#__PURE__*/__webpack_require__.n(ListItem_);
// EXTERNAL MODULE: external "@mui/material/ListItemButton"
var ListItemButton_ = __webpack_require__(1011);
var ListItemButton_default = /*#__PURE__*/__webpack_require__.n(ListItemButton_);
// EXTERNAL MODULE: external "@mui/material/ListItemText"
var ListItemText_ = __webpack_require__(8315);
var ListItemText_default = /*#__PURE__*/__webpack_require__.n(ListItemText_);
// EXTERNAL MODULE: external "@mui/icons-material/Menu"
var Menu_ = __webpack_require__(3365);
var Menu_default = /*#__PURE__*/__webpack_require__.n(Menu_);
// EXTERNAL MODULE: external "@mui/material/Toolbar"
var Toolbar_ = __webpack_require__(1431);
var Toolbar_default = /*#__PURE__*/__webpack_require__.n(Toolbar_);
// EXTERNAL MODULE: external "@mui/material/Typography"
var Typography_ = __webpack_require__(7163);
// EXTERNAL MODULE: external "@mui/material/Button"
var Button_ = __webpack_require__(3819);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button_);
// EXTERNAL MODULE: ./src/components/NavBar/NavBar.module.scss
var NavBar_module = __webpack_require__(5704);
var NavBar_module_default = /*#__PURE__*/__webpack_require__.n(NavBar_module);
;// CONCATENATED MODULE: ./src/components/NavBar/NavBar.jsx




















const drawerWidth = 240;
const navItems = [
    {
        "title": "Nuestro prop\xf3sito",
        "href": "/#wedo"
    },
    {
        "title": "Contacto",
        "href": "/#contact"
    },
    {
        "title": "Proyectos",
        "href": "/proyectos"
    }
];
function DrawerAppBar(props) {
    const { window  } = props;
    const [mobileOpen, setMobileOpen] = external_react_.useState(false);
    const handleDrawerToggle = ()=>{
        setMobileOpen((prevState)=>!prevState);
    };
    const drawer = /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Box_default()), {
        onClick: handleDrawerToggle,
        sx: {
            textAlign: "center"
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "/",
                children: /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                    className: (NavBar_module_default()).logoContainer,
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/icono-lv-negro.png",
                        width: 1018,
                        height: 877,
                        layout: "responsive",
                        alt: "logo"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            /*#__PURE__*/ jsx_runtime_.jsx((List_default()), {
                children: navItems.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                        disablePadding: true,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((ListItemButton_default()), {
                            sx: {
                                textAlign: "center"
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: `${item.href}`,
                                style: {
                                    textDecoration: "none",
                                    color: "inherit"
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                    primary: item.title
                                })
                            })
                        })
                    }, index))
            })
        ]
    });
    const container = window !== undefined ? ()=>window().document.body : undefined;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Box_default()), {
        sx: {
            display: "flex"
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((CssBaseline_default()), {}),
            /*#__PURE__*/ jsx_runtime_.jsx((AppBar_default()), {
                className: (NavBar_module_default()).themeBar,
                component: "nav",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Toolbar_default()), {
                    className: (NavBar_module_default()).toolBar,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                            color: "inherit",
                            "aria-label": "open drawer",
                            edge: "start",
                            onClick: handleDrawerToggle,
                            sx: {
                                mr: 2,
                                display: {
                                    sm: "none"
                                }
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((Menu_default()), {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                            className: (NavBar_module_default()).logoBox,
                            sx: {
                                flexGrow: 1,
                                display: {
                                    sm: "block"
                                }
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: "/logo-constructora-lv-white.png",
                                        width: 1480,
                                        height: 877,
                                        alt: "logo"
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                            sx: {
                                display: {
                                    xs: "none",
                                    sm: "block"
                                }
                            },
                            children: navItems.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                    sx: {
                                        color: "#fff"
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: `${item.href}`,
                                        style: {
                                            textDecoration: "none",
                                            color: "inherit"
                                        },
                                        children: item.title
                                    })
                                }, item))
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                component: "nav",
                children: /*#__PURE__*/ jsx_runtime_.jsx((Drawer_default()), {
                    container: container,
                    variant: "temporary",
                    open: mobileOpen,
                    onClose: handleDrawerToggle,
                    ModalProps: {
                        keepMounted: true
                    },
                    sx: {
                        display: {
                            xs: "block",
                            sm: "none"
                        },
                        "& .MuiDrawer-paper": {
                            boxSizing: "border-box",
                            width: drawerWidth
                        }
                    },
                    children: drawer
                })
            })
        ]
    });
}
DrawerAppBar.propTypes = {
    /**
   * Injected by the documentation to work in an iframe.
   * You won't need it on your project.
   */ window: (external_prop_types_default()).func
};
/* harmony default export */ const NavBar = (DrawerAppBar);

// EXTERNAL MODULE: ./src/components/Layouts/Layout/Layout.module.scss
var Layout_module = __webpack_require__(6991);
var Layout_module_default = /*#__PURE__*/__webpack_require__.n(Layout_module);
;// CONCATENATED MODULE: ./src/components/Layouts/Layout/Layout.jsx








function Layout({ children  }) {
    const matchesLg = useMediaQuery_default()("(min-width:1200px)");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_default()).Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Constructora LV"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Generated by create next app"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(NavBar, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Box_default()), {
                className: (Layout_module_default()).bodyPage,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                        children: children
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Footer_Footer, {})
                ]
            })
        ]
    });
}


/***/ })

};
;