exports.id = 642;
exports.ids = [642];
exports.modules = {

/***/ 6536:
/***/ ((module) => {

// Exports
module.exports = {
	"formPanel": "ContactForm_formPanel__X8GPO",
	"fullBorder": "ContactForm_fullBorder__zp72S",
	"formBox": "ContactForm_formBox__N138_",
	"inputField": "ContactForm_inputField__dmPNT"
};


/***/ }),

/***/ 5597:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ Button)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_1__);


const Button = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)((_mui_material_Button__WEBPACK_IMPORTED_MODULE_1___default()))(({ theme , secondary , w100 , small , uppercase , hoverWhite , opacity  })=>({
        fontFamily: "Roboto",
        opacity: opacity ? "80%" : 1,
        width: w100 ? "100%" : "auto",
        height: small ? "30px" : "40px",
        lineHeight: "120%",
        textTransform: uppercase ? "uppercase" : "initial",
        fontSize: small ? "0.850rem" : "0.950rem",
        backgroundColor: secondary ? theme.colors.secondary : theme.colors.white,
        color: secondary ? theme.colors.white : theme.colors.secondary,
        gap: "0.5rem",
        padding: "0.5rem 1rem",
        "&:hover": {
            backgroundColor: secondary ? theme.colors.primary : theme.colors.secondary,
            color: secondary ? theme.colors.secondary : theme.colors.white
        },
        "&:disabled,&[disabled]": {
            backgroundColor: theme.colors.disabled,
            color: "#5A6474",
            cursor: "not-allowed",
            pointerEvents: "initial"
        }
    }));


/***/ }),

/***/ 9642:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5612);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6042);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_Container__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4475);
/* harmony import */ var _mui_material_Container__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Container__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5641);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1908);
/* harmony import */ var _components_Buttons_Button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5597);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9648);
/* harmony import */ var _ContactForm_module_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6536);
/* harmony import */ var _ContactForm_module_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_ContactForm_module_scss__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_6__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_7__, axios__WEBPACK_IMPORTED_MODULE_10__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_6__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_7__, axios__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const ContactForm = ({ title , border  })=>{
    const schema = yup__WEBPACK_IMPORTED_MODULE_9__.object().shape({
        email: yup__WEBPACK_IMPORTED_MODULE_9__.string().email("El email debe poseer un formato correcto").required("El email es requerido"),
        name: yup__WEBPACK_IMPORTED_MODULE_9__.string().required("El nombre es requerido"),
        fullName: yup__WEBPACK_IMPORTED_MODULE_9__.string().required("El Apellido es requerido"),
        text: yup__WEBPACK_IMPORTED_MODULE_9__.string().required("El comentario es requerido")
    });
    const { register , handleSubmit , control , setValue , formState: { errors  } , reset  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_6__.useForm)({
        resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_7__.yupResolver)(schema)
    });
    const sendFormToEmail = async (data)=>{
        try {
            const response = await (0,axios__WEBPACK_IMPORTED_MODULE_10__["default"])({
                method: "post",
                url: "/api/sendEmail",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json"
                },
                data: JSON.stringify(data)
            });
            if (response.status == 200) {
                alert("Correo enviado con \xe9xito");
            } else {
                alert("Error al enviar correo");
            }
        } catch (error) {
            console.log("Fetch error: ", error);
        }
    };
    const formatData = (data)=>{
        const formData = {
            email: data.email,
            message: data.text,
            name: `${data.name.charAt(0).toUpperCase() + data.name.slice(1).toLowerCase()} ${data.fullName.charAt(0).toUpperCase() + data.fullName.slice(1).toLowerCase()}`,
            to: "contacto@lvconstructora.cl",
            subject: "Has sido contactado por un cliente"
        };
        return formData;
    };
    const onSubmit = (data)=>{
        try {
            // console.log('data:', data);
            const newData = formatData(data);
            console.log("newData:", newData);
            sendFormToEmail(newData);
            reset();
        } catch (e) {
            console.log("error");
        }
    };
    const onError = (error)=>{
        console.log("Fetch error: ", error);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: `contact-form ${(_ContactForm_module_scss__WEBPACK_IMPORTED_MODULE_11___default().formPanel)} ${border && (_ContactForm_module_scss__WEBPACK_IMPORTED_MODULE_11___default().fullBorder)}`,
        id: "contact",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Container__WEBPACK_IMPORTED_MODULE_5___default()), {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "title-container title-container__white",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "title",
                        children: title
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_2___default()), {
                    component: "form",
                    noValidate: true,
                    autoComplete: "off",
                    className: (_ContactForm_module_scss__WEBPACK_IMPORTED_MODULE_11___default().formBox),
                    onSubmit: handleSubmit(onSubmit, onError),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                            container: true,
                            spacing: 2,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    item: true,
                                    xs: 12,
                                    md: 6,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        className: (_ContactForm_module_scss__WEBPACK_IMPORTED_MODULE_11___default().inputField),
                                        fullWidth: true,
                                        type: "text",
                                        size: "small",
                                        required: true,
                                        id: "outlined-required",
                                        InputLabelProps: {
                                            shrink: true
                                        },
                                        label: "Nombre",
                                        placeholder: "Nombre",
                                        ...register("name"),
                                        error: Boolean(errors.name),
                                        helperText: errors.name ? errors.name.message : " "
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    item: true,
                                    xs: 12,
                                    md: 6,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        fullWidth: true,
                                        size: "small",
                                        required: true,
                                        id: "outlined-required",
                                        InputLabelProps: {
                                            shrink: true
                                        },
                                        label: "Apellido",
                                        ...register("fullName"),
                                        // error={Boolean(errors.email)}
                                        // helperText={errors.email ? errors.email.message : " "}
                                        variant: "outlined"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    item: true,
                                    xs: 12,
                                    md: 12,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        fullWidth: true,
                                        size: "small",
                                        required: true,
                                        id: "outlined-required",
                                        InputLabelProps: {
                                            shrink: true
                                        },
                                        label: "Correo electr\xf3nico",
                                        placeholder: "nombre@mail.com",
                                        ...register("email"),
                                        error: Boolean(errors.email),
                                        helperText: errors.email ? errors.email.message : " ",
                                        // defaultValue={email}
                                        variant: "outlined"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    item: true,
                                    xs: 12,
                                    md: 12,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        // label="Multiline"
                                        fullWidth: true,
                                        id: "standard-multiline-static",
                                        ...register("text"),
                                        placeholder: "Mensaje",
                                        sx: {
                                            "& .MuiInputBase-input": {
                                                fontSize: "1rem"
                                            }
                                        },
                                        multiline: true,
                                        rows: 3,
                                        variant: "filled",
                                        error: Boolean(errors.text),
                                        helperText: errors.text ? errors.text.message : " ",
                                        className: (_ContactForm_module_scss__WEBPACK_IMPORTED_MODULE_11___default().customBox)
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Buttons_Button__WEBPACK_IMPORTED_MODULE_8__/* .Button */ .z, {
                            type: "submit",
                            children: "Enviar comentario "
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ContactForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;