"use strict";
(() => {
var exports = {};
exports.id = 719;
exports.ids = [719];
exports.modules = {

/***/ 8904:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ sendEmail)
});

;// CONCATENATED MODULE: external "nodemailer"
const external_nodemailer_namespaceObject = require("nodemailer");
var external_nodemailer_default = /*#__PURE__*/__webpack_require__.n(external_nodemailer_namespaceObject);
;// CONCATENATED MODULE: ./public/img_mail.png
/* harmony default export */ const img_mail = ({"src":"/_next/static/media/img_mail.9012c37f.png","height":200,"width":600,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAIAAAAhqtkfAAAAVklEQVR42gFLALT/ACA4ViM6WBs0U52nu8PL2v36+fHo4mNxjAAvQl09TWY0RWDS2+7By9/Ky9PM0d08e7YAPEtkU19zABRCiZOlr7rPGjtcl7bZTn+yi/cmGQWGz9YAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":3});
;// CONCATENATED MODULE: ./src/pages/api/sendEmail.js


/* harmony default export */ const sendEmail = (async (req, res)=>{
    // console.log('rer:', req.body);
    try {
        const transporter = external_nodemailer_default().createTransport({
            host: "mail.lvconstructora.cl",
            port: 465,
            secure: true,
            //service: 'Gmail', // o tu proveedor de correo electrónico preferido
            auth: {
                user: "contacto@lvconstructora.cl",
                pass: "Pablo.avc0"
            }
        });
        const mailOptions = {
            from: "contacto@lvconstructora.cl",
            to: req.body.to,
            subject: req.body.subject,
            text: req.body.message,
            html: `
      <table style="width: 100%; border-collapse: collapse; display: flex; justify-content: center; align-items: center;text-align: center;">
      <tr>
        <td style="text-align: center;">
          <div style="position: relative; width: 70%; padding-bottom: 0; box-shadow: 0 2px 8px 0 rgba(63,69,81,0.16); margin-top: 1.6em; margin-bottom: 0.9em; overflow: hidden; border-radius: 8px; will-change: transform;">
            <a href="https://lvconstructora.cl/" target="_blank" rel="noopener">
              <img style="position: absolute; width: 100%; height: 100%; top: 0; left: 0; border: none; padding: 0;margin: 0;" src="https://eelwces.stripocdn.email/content/guids/CABINET_a476daa5b0a44fc43d6f19c7f0e5bc1f3e23713aa59ea8a238a4a787c290f509/images/blue_simple_corporate_email_header.png" alt="logo-email" >
            </a>
          </div>
        </td>
      </tr>
      <tr>
        <td style="text-align: center;">
          <div style="width: 70%;">
            <h3 style="margin-top: 2rem;">Has recibido un mensaje de contacto</h3>
            <p style="text-align: justify;"><strong>Nombre:</strong> ${req.body.name}</p>
            <p style="text-align: justify;"><strong>Email:</strong> ${req.body.email}</p>
            <p style="text-align: justify;"><strong>Mensaje:</strong></p>
            <p style="text-align: justify;">${req.body.message}</p>
          </div>
        </td>
      </tr>
    </table>
    
      
      `
        };
        console.log(mailOptions);
        await transporter.sendMail(mailOptions);
        res.status(200).json({
            message: "Correo enviado con \xe9xito"
        });
    } catch (error) {
        console.error("Error al enviar el correo:", error);
        res.status(500).json({
            error: error
        });
    }
});


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(8904));
module.exports = __webpack_exports__;

})();